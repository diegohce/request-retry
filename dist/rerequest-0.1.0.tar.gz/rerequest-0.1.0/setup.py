# -*- coding: utf-8 -*-
from distutils.core import setup

modules = \
['rerequest']
install_requires = \
['requests==2.22.0']

setup_kwargs = {
    'name': 'rerequest',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Diego Cena',
    'author_email': 'diego.cena@gmail.com',
    'url': None,
    'py_modules': modules,
    'install_requires': install_requires,
    'python_requires': '>=3.6,<4.0',
}


setup(**setup_kwargs)
